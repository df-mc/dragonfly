module github.com/df-mc/dragonfly

go 1.26.0

require (
	github.com/brentp/intintmap v0.0.0-20251106190759-56907b1f8479
	github.com/cespare/xxhash/v2 v2.3.0
	github.com/df-mc/goleveldb v1.1.9
	github.com/df-mc/worldupgrader v1.0.20
	github.com/go-gl/mathgl v1.2.0
	github.com/google/uuid v1.6.0
	github.com/pelletier/go-toml v1.9.5
	github.com/sandertv/gophertunnel v1.56.2
	github.com/segmentio/fasthash v1.0.3
	golang.org/x/exp v0.0.0-20250103183323-7d7fa50e5329
	golang.org/x/mod v0.22.0
	golang.org/x/text v0.23.0
	golang.org/x/tools v0.28.0
)

require (
	github.com/coreos/go-oidc/v3 v3.17.0 // indirect
	github.com/df-mc/go-playfab v1.0.0 // indirect
	github.com/df-mc/go-xsapi v1.0.1 // indirect
	github.com/df-mc/jsonc v1.0.5 // indirect
	github.com/go-jose/go-jose/v4 v4.1.3 // indirect
	github.com/golang/snappy v0.0.4 // indirect
	github.com/klauspost/compress v1.18.4 // indirect
	github.com/sandertv/go-raknet v1.15.1-0.20260112202637-beca0b10c217 // indirect
	golang.org/x/net v0.38.0 // indirect
	golang.org/x/oauth2 v0.28.0 // indirect
	golang.org/x/sync v0.12.0 // indirect
	gopkg.in/yaml.v2 v2.3.0 // indirect
)
